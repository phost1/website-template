## Sidefolio - Portfolio website template

As seen on [Aceternity UI](https://ui.aceternity.com/templtes/sidefolio)

## Built with
- Next.js
- Tailwindcss
- Framer motion
- MDX

Checkout all the templates at [Aceternity UI](https://ui.aceternity.com/templates)
